<?php

$cv = "
<html>

<head>
<title>Tanmay Naik</title>

<meta http-equiv=Content-Type content=\"text/html; charset=windows-1252\">
<meta name=Generator content=\"Microsoft Word 15 (filtered)\">
<style>
<!--
 /* Font Definitions */
 @font-face
	{font-family:Wingdings;
	panose-1:5 0 0 0 0 0 0 0 0 0;}
@font-face
	{font-family:\"Cambria Math\";
	panose-1:2 4 5 3 5 4 6 3 2 4;}
@font-face
	{font-family:Calibri;
	panose-1:2 15 5 2 2 2 4 3 2 4;}
@font-face
	{font-family:Georgia;
	panose-1:2 4 5 2 5 4 5 2 3 3;}
@font-face
	{font-family:\"Wingdings 2\";
	panose-1:5 2 1 2 1 5 7 7 7 7;}
 /* Style Definitions */
 p.MsoNormal, li.MsoNormal, div.MsoNormal
	{margin:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;}
h1
	{mso-style-link:\"Heading 1 Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#741B47;
	text-transform:uppercase;
	letter-spacing:2.0pt;}
h1.CxSpFirst
	{mso-style-link:\"Heading 1 Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#741B47;
	text-transform:uppercase;
	letter-spacing:2.0pt;}
h1.CxSpMiddle
	{mso-style-link:\"Heading 1 Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#741B47;
	text-transform:uppercase;
	letter-spacing:2.0pt;}
h1.CxSpLast
	{mso-style-link:\"Heading 1 Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#741B47;
	text-transform:uppercase;
	letter-spacing:2.0pt;}
h2
	{mso-style-link:\"Heading 2 Char\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#4C1130;
	text-transform:uppercase;
	letter-spacing:1.0pt;}
h2.CxSpFirst
	{mso-style-link:\"Heading 2 Char\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#4C1130;
	text-transform:uppercase;
	letter-spacing:1.0pt;}
h2.CxSpMiddle
	{mso-style-link:\"Heading 2 Char\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#4C1130;
	text-transform:uppercase;
	letter-spacing:1.0pt;}
h2.CxSpLast
	{mso-style-link:\"Heading 2 Char\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#4C1130;
	text-transform:uppercase;
	letter-spacing:1.0pt;}
p.MsoTitle, li.MsoTitle, div.MsoTitle
	{mso-style-link:\"Title Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:14.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;
	font-weight:bold;}
p.MsoTitleCxSpFirst, li.MsoTitleCxSpFirst, div.MsoTitleCxSpFirst
	{mso-style-link:\"Title Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:14.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;
	font-weight:bold;}
p.MsoTitleCxSpMiddle, li.MsoTitleCxSpMiddle, div.MsoTitleCxSpMiddle
	{mso-style-link:\"Title Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:14.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;
	font-weight:bold;}
p.MsoTitleCxSpLast, li.MsoTitleCxSpLast, div.MsoTitleCxSpLast
	{mso-style-link:\"Title Char\";
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:14.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;
	font-weight:bold;}
a:link, span.MsoHyperlink
	{color:blue;
	text-decoration:underline;}
a:visited, span.MsoHyperlinkFollowed
	{color:purple;
	text-decoration:underline;}
p.MsoNoSpacing, li.MsoNoSpacing, div.MsoNoSpacing
	{margin:0cm;
	margin-bottom:.0001pt;
	font-size:11.0pt;
	font-family:\"Cambria\",serif;}
p.MsoListParagraph, li.MsoListParagraph, div.MsoListParagraph
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:90.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
p.MsoListParagraphCxSpFirst, li.MsoListParagraphCxSpFirst, div.MsoListParagraphCxSpFirst
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:90.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
p.MsoListParagraphCxSpMiddle, li.MsoListParagraphCxSpMiddle, div.MsoListParagraphCxSpMiddle
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:90.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
p.MsoListParagraphCxSpLast, li.MsoListParagraphCxSpLast, div.MsoListParagraphCxSpLast
	{margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:90.0pt;
	margin-bottom:.0001pt;
	text-indent:-18.0pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
span.TitleChar
	{mso-style-name:\"Title Char\";
	mso-style-link:Title;
	font-family:\"Georgia\",serif;
	color:#666666;
	font-weight:bold;}
p.Contact, li.Contact, div.Contact
	{mso-style-name:Contact;
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;}
p.ContactCxSpFirst, li.ContactCxSpFirst, div.ContactCxSpFirst
	{mso-style-name:ContactCxSpFirst;
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;}
p.ContactCxSpMiddle, li.ContactCxSpMiddle, div.ContactCxSpMiddle
	{mso-style-name:ContactCxSpMiddle;
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;}
p.ContactCxSpLast, li.ContactCxSpLast, div.ContactCxSpLast
	{mso-style-name:ContactCxSpLast;
	margin:0cm;
	margin-bottom:.0001pt;
	text-align:center;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Georgia\",serif;
	color:#666666;}
span.Heading1Char
	{mso-style-name:\"Heading 1 Char\";
	mso-style-link:\"Heading 1\";
	font-family:\"Georgia\",serif;
	color:#741B47;
	text-transform:uppercase;
	letter-spacing:2.0pt;
	font-weight:bold;}
span.Heading2Char
	{mso-style-name:\"Heading 2 Char\";
	mso-style-link:\"Heading 2\";
	font-family:\"Arial\",sans-serif;
	color:#4C1130;
	text-transform:uppercase;
	letter-spacing:1.0pt;
	font-weight:bold;}
p.Normalwithleftindent, li.Normalwithleftindent, div.Normalwithleftindent
	{mso-style-name:\"Normal with left indent\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
p.NormalwithleftindentCxSpFirst, li.NormalwithleftindentCxSpFirst, div.NormalwithleftindentCxSpFirst
	{mso-style-name:\"Normal with left indentCxSpFirst\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
p.NormalwithleftindentCxSpMiddle, li.NormalwithleftindentCxSpMiddle, div.NormalwithleftindentCxSpMiddle
	{mso-style-name:\"Normal with left indentCxSpMiddle\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
p.NormalwithleftindentCxSpLast, li.NormalwithleftindentCxSpLast, div.NormalwithleftindentCxSpLast
	{mso-style-name:\"Normal with left indentCxSpLast\";
	margin-top:0cm;
	margin-right:0cm;
	margin-bottom:0cm;
	margin-left:72.0pt;
	margin-bottom:.0001pt;
	line-height:115%;
	font-size:10.0pt;
	font-family:\"Arial\",sans-serif;
	color:#666666;}
.MsoChpDefault
	{font-family:\"Calibri\",sans-serif;}
.MsoPapDefault
	{margin-bottom:10.0pt;
	line-height:115%;}
@page WordSection1
	{size:612.0pt 792.0pt;
	margin:36.0pt 36.0pt 36.0pt 36.0pt;}
div.WordSection1
	{page:WordSection1;}
 /* List Definitions */
 ol
	{margin-bottom:0cm;}
ul
	{margin-bottom:0cm;}
-->
</style>

</head>

<body lang=EN-GB link=blue vlink=purple>

<div class=WordSection1>

<p class=MsoNormal><span lang=EN-US style='color:#666666'>&nbsp;</span></p>

<p class=MsoTitle><a name=h.ydgpbs5gi5fx></a><span lang=EN-US>Tanmay Naik</span></p>

<p class=MsoNormal><span lang=EN-US>&nbsp;</span></p>
<p class=ContactCxSpFirst><span lang=EN-US>27, China Gate 2, New CityLight Area, Surat</span></p>
<p class=ContactCxSpMiddle><span lang=EN-US>+91 9429368682</span></p>
<p class=ContactCxSpLast><span lang=EN-US>tanmaysnaik@yahoo.in</span></p>
<p class=MsoNormal><span lang=EN-US>&nbsp;</span></p>

<div style='border:none;border-bottom:solid windowtext 1.0pt;padding:0cm 0cm 5.0pt 0cm'><div style='border:none;border-bottom:solid windowtext 1.0pt;padding:0cm 0cm 1.0pt 0cm'>

<p class=MsoNormalCxSpFirst align=center style='text-align:center;border:none;
padding:0cm'><span lang=EN-US style='font-family:\"Georgia\",serif;color:#666666'>&nbsp;</span></p>

</div>

<p class=MsoNormalCxSpMiddle><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#666666'>&nbsp;</span></b></p>

<p class=MsoNormalCxSpLast><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#666666'>&nbsp;</span></b></p>

<p class=MsoNormalCxSpLast><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#741B47;text-transform:uppercase;letter-spacing:2.0pt'>Objective</span></b></p>

<p class=MsoNormal><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#741B47;text-transform:uppercase;letter-spacing:2.0pt'>        </span></b></p>

<p class=Normalwithleftindent><span lang=DE>I am seeking a company where I can use my experience and education to help the company meet and surpass its goals.
I want to share my high level of skills on most languages and work on real life problems.</span></p>
<br>
<p class=MsoNormalCxSpLast><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#741B47;text-transform:uppercase;letter-spacing:2.0pt'>EDUCATION</span></b></p>

<p class=MsoListParagraphCxSpFirst><span lang=EN-US style='font-size:14.0pt;
line-height:115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>12th HSC from Jeevan Bharti, Surat</span></p>

<p class=MsoListParagraphCxSpFirst><span lang=EN-US style='font-size:14.0pt;
line-height:115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>B. Tech in Computer Engineering from DDIT, Nadiad</span></p>

<p class=MsoListParagraphCxSpFirst><span lang=EN-US style='font-size:14.0pt;
line-height:115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>MS in Computer Science from MIT, Massachusetts</span></p>

        <br><p class=MsoNormalCxSpMiddle><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#741B47;text-transform:uppercase;letter-spacing:2.0pt'>Experience</span></b></p>



<h2><span lang=EN-US>Assistant Software Developer at Infosys</span></h2><br>

<p class=MsoListParagraph><span lang=EN-US style='font-size:14.0pt;line-height:
115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>Design, develop and maintain the operation of database-driven ASP .NET/C# Web applications, with a specific emphasis on usability, performance and scalability.</span></p>

<br>
<h2><span lang=EN-US>Web Developer at Cisco</span></h2><br>

<p class=MsoListParagraph><span lang=EN-US style='font-size:14.0pt;line-height:
115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>Build the operations end of the organization's websites and keep them running smoothly.</span></p>
<br>

<p class=MsoNormalCxSpLast><b><span lang=EN-US style='font-family:\"Georgia\",serif;
color:#741B47;text-transform:uppercase;letter-spacing:2.0pt'>Skills</span></b></p>
<p class=MsoListParagraphCxSpFirst><span lang=EN-US style='font-size:14.0pt;
line-height:115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>JavaEE applications development</span></p>
<p class=MsoListParagraphCxSpFirst><span lang=EN-US style='font-size:14.0pt;
line-height:115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>Algorithms Design & Analysis expert</span></p>
<p class=MsoListParagraphCxSpFirst><span lang=EN-US style='font-size:14.0pt;
line-height:115%;font-family:\"Wingdings 2\";color:#244A58;letter-spacing:3.0pt'>å<span
style='font:7.0pt \"Times New Roman\"'> </span></span><span lang=EN-US>IIT-B Certified Linux programmer</span></p>
</div></body><script language=\"javascript\" type=\"text/javascript\">
<!--
   window.print();
//-->
</script>
</html>
";

        

        $cv .= "</table>";

        $cv .= "</div></body>,</HTML>";


    

   /* $mpdf=new mPDF('c','A4','','',32,25,27,25,16,13);
    $mpdf->SetDisplayMode('fullpage');
    $mpdf->list_indent_first_level = 0;
    $mpdf->WriteHTML($html);
    $mpdf->Output('mpdf.pdf','D');*/

   






    /*$html2pdf = new HTML2PDF('P','A4','en');
    $html2pdf->WriteHTML($cv);
    $html2pdf->Output('example.pdf');*/





?>
